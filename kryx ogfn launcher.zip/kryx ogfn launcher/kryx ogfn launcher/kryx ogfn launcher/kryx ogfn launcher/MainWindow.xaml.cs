using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;
using Wpf.Ui;
using Wpf.Ui.Appearance;
using Wpf.Ui.Controls;
using TextBlock = System.Windows.Controls.TextBlock;

namespace LuxMP
{
    public partial class MainWindow : FluentWindow
    {
        private bool _settingBackend = false;

        public MainWindow()
        {
            ApplicationThemeManager.ApplySystemTheme(true);
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(Settings.Default.username) || string.IsNullOrEmpty(Settings.Default.password))
            {
                var login = new LoginWindow();
                if (login.ShowDialog() != true) { Application.Current.Shutdown(); return; }
            }

            welcomeLabel.Text = Settings.Default.username;

            if (!string.IsNullOrEmpty(Settings.Default.path))
            {
                pathDisplay.Text = Settings.Default.path;
                pathPlaceholder.Visibility = Visibility.Hidden;
                pathText.Content = Settings.Default.path;
            }

            username.Text = Settings.Default.username;
            password.Password = Settings.Default.password;

            _settingBackend = true;
            backend.Text = Settings.Default.backend;
            backendSetting.Text = Settings.Default.backend;
            _settingBackend = false;
        }

        private void SetTab(string name)
        {
            panelHome.Visibility = name == "home" ? Visibility.Visible : Visibility.Collapsed;
            panelLaunch.Visibility = name == "launch" ? Visibility.Visible : Visibility.Collapsed;
            panelSettings.Visibility = name == "settings" ? Visibility.Visible : Visibility.Collapsed;
            panelCredits.Visibility = name == "credits" ? Visibility.Visible : Visibility.Collapsed;
            tabBtnHome.Style = (Style)FindResource(name == "home" ? "NavBtnActive" : "NavBtn");
            tabBtnLaunch.Style = (Style)FindResource(name == "launch" ? "NavBtnActive" : "NavBtn");
            tabBtnSettings.Style = (Style)FindResource(name == "settings" ? "NavBtnActive" : "NavBtn");
            tabBtnCredits.Style = (Style)FindResource(name == "credits" ? "NavBtnActive" : "NavBtn");
        }

        private void ShowHomeTab(object sender, RoutedEventArgs e) => SetTab("home");
        private void ShowLaunchTab(object sender, RoutedEventArgs e) => SetTab("launch");
        private void ShowSettingsTab(object sender, RoutedEventArgs e) => SetTab("settings");
        private void ShowCreditsTab(object sender, RoutedEventArgs e) => SetTab("credits");

        private void LogoutClick(object sender, RoutedEventArgs e)
        {
            Settings.Default.username = "";
            Settings.Default.password = "";
            Settings.Default.Save();
            var login = new LoginWindow();
            if (login.ShowDialog() == true)
            {
                welcomeLabel.Text = Settings.Default.username;
                username.Text = Settings.Default.username;
                password.Password = Settings.Default.password;
            }
            else Application.Current.Shutdown();
        }

        private void setUsername(object sender, RoutedEventArgs e)
        {
            if (exchange.IsChecked == false) { Settings.Default.username = username.Text; Settings.Default.Save(); }
        }

        private void setPassword(object sender, RoutedEventArgs e)
        {
            Settings.Default.password = password.Password; Settings.Default.Save();
        }

        private void setBackend(object sender, RoutedEventArgs e)
        {
            if (_settingBackend) return;
            var tb = sender as Wpf.Ui.Controls.TextBox;
            if (tb == null) return;
            _settingBackend = true;
            Settings.Default.backend = tb.Text;
            Settings.Default.Save();
            if (backend != null) backend.Text = tb.Text;
            if (backendSetting != null) backendSetting.Text = tb.Text;
            _settingBackend = false;
        }

        private void selectFolder(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFolderDialog { Title = "Select Fortnite folder" };
            if (dlg.ShowDialog() == true)
            {
                pathText.Content = dlg.FolderName;
                pathDisplay.Text = dlg.FolderName;
                pathPlaceholder.Visibility = Visibility.Hidden;
                Settings.Default.path = dlg.FolderName;
                Settings.Default.Save();
            }
        }

        private void doExchange(object sender, RoutedEventArgs e)
        {
            password.Visibility = Visibility.Hidden;
            passwordLabel.Visibility = Visibility.Hidden;
            emailLabel.Text = "EXCHANGE CODE";
            username.PlaceholderText = "Exchange code...";
            username.Text = "";
        }

        private void undoExchange(object sender, RoutedEventArgs e)
        {
            password.Visibility = Visibility.Visible;
            passwordLabel.Visibility = Visibility.Visible;
            emailLabel.Text = "EMAIL";
            username.PlaceholderText = "email@domain.com";
            username.Text = Settings.Default.username;
        }

        private async void launchGame(object sender, RoutedEventArgs e)
        {
            string path = pathText.Content?.ToString() ?? "";
            string exe = Path.Join(path, "FortniteGame", "Binaries", "Win64", "FortniteClient-Win64-Shipping.exe");
            if (!File.Exists(exe)) { statusLabel.Text = "Error: game not found at path."; SetTab("launch"); return; }

            launch.IsEnabled = false;
            statusLabel.Text = "LAUNCHING LUX...";

            try
            {
                ResourceManager rm = new ResourceManager("LuxMP.g", Assembly.GetExecutingAssembly());
                Stream? s = rm.GetStream("starfall.dll");
                string tmp = Path.GetTempFileName();
                using (FileStream fs = File.OpenWrite(tmp)) { s?.Seek(0L, SeekOrigin.Begin); s?.CopyTo(fs); }
                File.Copy(tmp, Path.Join(path, "Engine", "Binaries", "ThirdParty", "NVIDIA", "NVaftermath", "Win64", "GFSDK_Aftermath_Lib.x64.dll"), overwrite: true);
                File.Copy(tmp, Path.Join(path, "Engine", "Binaries", "ThirdParty", "NVIDIA", "NVaftermath", "Win64", "GFSDK_Aftermath_Lib.dll"), overwrite: true);
                File.Delete(tmp);
            }
            catch { statusLabel.Text = "Error copying files."; launch.IsEnabled = true; return; }

            Process.GetProcessesByName("FortniteClient-Win64-Shipping").ToList().ForEach(x => { try { x.Kill(); } catch { } });

            string auth = exchange.IsChecked == true ? "unused" : username.Text;
            string pass = exchange.IsChecked == true ? username.Text : password.Password;
            string type = exchange.IsChecked == true ? "exchangecode" : "epic";
            string back = Settings.Default.backend;
            string args = $"-epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -nobe -fromfl=eac -fltoken=h1cdhchd10150221h130eB56 -skippatchcheck -caldera=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50X2lkIjoiMTM5ZDAzOGFmOTM2NDcyODgxMTdlYWU3MWYxZGQ5ZTQiLCJnZW5lcmF0ZWQiOjE3MDQ0MTE5MDQsImNhbGRlcmFHdWlkIjoiODhjZmQ5NzYtM2U2OS00MWYzLWI2ODEtYzQyOTcxM2ZkMWFlIiwiYWNQcm92aWRlciI6IkVhc3lBbnRpQ2hlYXQiLCJub3RlcyI6IiIsImZhbGxiYWNrIjpmYWxzZX0.Q8hdxvrW2sH-3on6JEBLANB0rkPAGUwbZYPrCOMTtvA -AUTH_LOGIN={auth} -AUTH_PASSWORD={pass} -AUTH_TYPE={type} -backend={back}";

            Process? FN = Proc.Start(path, "FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping.exe", args);
            Process? AC = Proc.Start(path, "FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping_EAC.exe", "-epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -nobe -fromfl=eac -fltoken=h1cdhchd10150221h130eB56 -skippatchcheck", suspend: true);
            Process? LC = Proc.Start(path, "FortniteGame\\Binaries\\Win64\\FortniteLauncher.exe", "-epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -nobe -fromfl=eac -fltoken=h1cdhchd10150221h130eB56 -skippatchcheck", suspend: true);

            statusLabel.Text = "Running...";
            await Task.Run(() => { try { FN!.WaitForInputIdle(); } catch { } });
            await FN!.WaitForExitAsync();
            try { AC!.Kill(); LC!.Kill(); } catch { }

            statusLabel.Text = "";
            launch.IsEnabled = true;
        }

        private string TrimPath(string p) => p.Length > 38 ? "..." + p[^35..] : p;
    }
}
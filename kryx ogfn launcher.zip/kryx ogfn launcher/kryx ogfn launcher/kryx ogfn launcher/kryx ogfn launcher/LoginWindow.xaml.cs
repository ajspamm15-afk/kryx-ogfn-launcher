using System.Windows;
using Wpf.Ui.Controls;

namespace LuxMP
{
    public partial class LoginWindow : FluentWindow
    {
        public string Email { get; private set; } = "";
        public string Password { get; private set; } = "";

        public LoginWindow() => InitializeComponent();

        private void SignIn_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(loginEmail.Text))
            {
                errorText.Text = "Please enter your email.";
                errorText.Visibility = Visibility.Visible;
                return;
            }
            if (string.IsNullOrWhiteSpace(loginPassword.Password))
            {
                errorText.Text = "Please enter your password.";
                errorText.Visibility = Visibility.Visible;
                return;
            }
            Email = loginEmail.Text.Trim();
            Password = loginPassword.Password;
            Settings.Default.username = Email;
            Settings.Default.password = Password;
            Settings.Default.Save();
            DialogResult = true;
            Close();
        }
    }
}
